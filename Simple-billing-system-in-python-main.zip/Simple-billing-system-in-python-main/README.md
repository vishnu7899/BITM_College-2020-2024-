# Simple-billing-system-in-python

This project is a simple billing system developed in Python. The program takes a customer's name and the items they have purchased, along with their respective prices, and generates a receipt with a unique receipt number. The program is built using basic input/output functions and list manipulation in Python.
